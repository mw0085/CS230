<body>
    <link rel="stylesheet" href="css/about.css">

    <div class="about">
        <h1>About Us</h1>

        <p>Everything Jar Jar</p>

    </div>

    <div class ="row">
        <div class = "column">
            <div class = "card">
                <img src="images/2.jpeg">
                <div class = "container">
                    <h2>CEO</h2>
                    <p>Jar Jar Binks</p>
                    <p>Email: Messaemail@mail.com</p>
                </div>
            </div>
        </div>
        <div class ="row">
            <div class = "column">
                <div class = "card">
                    <img src="images/1.jpeg">
                    <div class = "container">
                        <h2>Supreme Leader</h2>
                        <p>Jar Jar Binks</p>
                        <p>Email: Messaemail@mail.com</p>
                    </div>
                </div>
            </div>
            <div class ="row">
                <div class = "column">
                    <div class = "card">
                        <img src="images/3.jpeg">
                        <div class = "container">
                            <h2>King</h2>
                            <p>Jar Jar Binks</p>
                            <p>Email: Messaemail@mail.com</p>
                        </div>
                    </div>
                </div>
                <div class ="row">
                    <div class = "column">
                        <div class = "card">
                            <img src="images/4.jpeg">
                            <div class = "container">
                                <h2>Icon</h2>
                                <p>Jar Jar Binks</p>
                                <p>Email: Messaemail@mail.com</p>
                            </div>
                        </div>
                    </div>    
    </div>
</body>